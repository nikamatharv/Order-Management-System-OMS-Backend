package com.rajithadev.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import io.swagger.v3.oas.annotations.info.Info;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;


@OpenAPIDefinition(info = @Info(title = "Order Management API", version = "1.0", description = "API Documentation"))
@SpringBootApplication
public class OrderMgtApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderMgtApplication.class, args);
	}

}
