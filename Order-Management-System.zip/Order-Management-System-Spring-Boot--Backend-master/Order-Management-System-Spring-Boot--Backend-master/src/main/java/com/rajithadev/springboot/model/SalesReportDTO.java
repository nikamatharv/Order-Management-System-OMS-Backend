package com.rajithadev.springboot.model;



import java.math.BigDecimal;

public class SalesReportDTO {
    private String productName;
    private Long totalOrders;
    private BigDecimal totalRevenue;

    public SalesReportDTO(String productName, Long totalOrders, BigDecimal totalRevenue) {
        this.productName = productName;
        this.totalOrders = totalOrders;
        this.totalRevenue = totalRevenue;
    }

    public String getProductName() { return productName; }
    public Long getTotalOrders() { return totalOrders; }
    public BigDecimal getTotalRevenue() { return totalRevenue; }
}

