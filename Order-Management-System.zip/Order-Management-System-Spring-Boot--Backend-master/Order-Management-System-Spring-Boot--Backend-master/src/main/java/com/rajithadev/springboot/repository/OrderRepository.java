package com.rajithadev.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rajithadev.springboot.model.Order;
import com.rajithadev.springboot.model.SalesReportDTO;

public interface OrderRepository extends JpaRepository<Order, Long>{
	@Query(value = "SELECT p.name, COUNT(o.id) AS orderCount, SUM(o.total_amount) AS totalSales " +
            "FROM orders o INNER JOIN products p ON o.product_id = p.id " +
            "GROUP BY p.name", nativeQuery = true)
List<Object[]> getSalesReport();



	
}
