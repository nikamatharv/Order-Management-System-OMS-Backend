package com.rajithadev.springboot.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rajithadev.springboot.model.Order;
import com.rajithadev.springboot.model.SalesReportDTO;
import com.rajithadev.springboot.repository.OrderRepository;
import com.rajithadev.springboot.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {

	private OrderRepository orderRepository;
	

	@Autowired
	public OrderServiceImpl(OrderRepository orderRepository) {
		this.orderRepository = orderRepository;
	}

	@Override
	public List<Order> orderList() {
		return orderRepository.findAll();
	}

	@Override
	public Optional<Order> findById(Long id) {
		return orderRepository.findById(id);
	}

	@Override
	public Order addOrder(Order order) {
		return orderRepository.save(order);
	}

    public List<SalesReportDTO> getSalesReport() {
        List<Object[]> results = orderRepository.getSalesReport();
        List<SalesReportDTO> salesReport = new ArrayList<>();

        for (Object[] row : results) {
            SalesReportDTO dto = new SalesReportDTO(
                (String) row[0], // product name
                ((Number) row[1]).longValue(), // total orders (convert to Long)
                (row[2] != null) ? new BigDecimal(row[2].toString()) : BigDecimal.ZERO // total revenue
            );
            salesReport.add(dto);
        }
        return salesReport;
    }

    @Override
    public String deleteOrder(Long id) {
        orderRepository.deleteById(id);
        return "{'Message' : 'Order deleted Successfully'}";
    }

}
